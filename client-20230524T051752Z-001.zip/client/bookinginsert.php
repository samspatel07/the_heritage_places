<?php
require_once("../config/connection1.php");
session_start();
$d = date('Y-m-d');
	$uid=$_SESSION['user_id'];
	$pid=$_GET['museumid'];
	$qty = $_GET['qty'];



	$sql1 = "select Price from museum where museum_id = '".$pid."'";
	$result1 = mysqli_query($conn,$sql1);
	$row1 = mysqli_fetch_array($result1);
	$amt = $row1['Price'];
	$total = $amt * $qty;



	  $sql3 = "select * from booking where museum_id=$pid and user_id=$uid";

	   $result3 = mysqli_query($conn,$sql3);

	
		$row3 = mysqli_fetch_array($result3);


		$sql="insert into booking(booking_date,user_id,museum_id,noofperson,totalprice,payment_status)
		values('".$d."','".$uid."','".$pid."','".$qty."','".$total."',0)";
		//echo $sql;
		//die;


	  $result=mysqli_query($conn,$sql);

	  if($result)
	  {
		  	$bid = mysqli_insert_id($conn);
		  //echo "<meta http-equiv='refresh' content='0;url=booking.php'>";
		   echo "<meta http-equiv='refresh' content='0;url=summary.php?bid=$bid'>";
	  }


			  ?>
