<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="adminindex.php">Dashboard</a>
        </li>
        
      </ol>
	  <!--a href="insert1.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-tablet"></i><h2>Booking</h2></div>
		  <div >
		  <a href="Reports/museum.php"><button  type="submit" class="btn btn-success">generate report</button></a><br><br>
		  </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>booking date</th>
                  <th>museum name</th>
                  <th>user name</th>
                  <th>noofperson</th>
				  <th>totalprice</th>
				  <th>payment status</th>
				  <!--th>action</th-->
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "select * from booking b join museum m join user u where b.museum_id = m.museum_id and b.user_id = u.user_id ";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['booking_date'];?></td>
			<td> <?php echo $row['museum_name'];?></td>
			<td> <?php echo $row['user_name'];?></td>
			<td> <?php echo $row['noofperson'];?></td>
			<td> <?php echo $row['totalprice'];?></td>
			<td> <?php
			if ($row['payment_status']==0)
			{
				echo "Succesfully paid";
			}
			else
			{
				echo "Pending";
			}
			?></td>
			<!--td> <a href="delete1.php?id=<?php echo $row['user_id']?>">DELETE</a></td>
			<td> <a href="update1.php?id=<?php echo $row['user_id']?>">UPDATE</a></td-->
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       
      </div>
    </div>
   <?php require'footer.php';?>
</html>