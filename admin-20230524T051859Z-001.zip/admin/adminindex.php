<!DOCTYPE html>
<?php include("header.php");
require_once("../config/connection1.php");

?>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>


<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">My Dashboard</li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
	      <?php
					$sql="SELECT COUNT(*) as total from user";
					$result=mysqli_query($conn,$sql);
					$row=mysqli_fetch_array ($result);
					
					
						?>             
	  
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-comments"></i>
              </div>
              <div class="mr-5"> Total Users <?php echo $row['total'] ?></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              
              
            </a>
          </div>
        </div>

                    
		 <?php
					$sql="SELECT COUNT(*) as total from museum";
					$result=mysqli_query($conn,$sql);
					$row=mysqli_fetch_array ($result);
					
					
						?> 
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-warning o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-list"></i>
              </div>
              <div class="mr-5"> Museums <?php echo $row['total'] ?></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              
            </a>
          </div>
        </div>
		 <?php
					$sql="SELECT COUNT(*) as total from booking";
					$result=mysqli_query($conn,$sql);
					$row=mysqli_fetch_array ($result);
					
					
						?> 
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-success o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-shopping-cart"></i>
              </div>
              <div class="mr-5"> Bookings <?php echo $row['total'] ?> </div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              
            </a>
          </div>
        </div>
		 <?php
					$sql="SELECT COUNT(*) as total from feedback";
					$result=mysqli_query($conn,$sql);
					$row=mysqli_fetch_array ($result);
					
					
						?>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-danger o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-support"></i>
              </div>
              <div class="mr-5">Total feedback <?php echo $row['total'] ?> </div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">

            </a>
          </div>
        </div>
      </div>
     
     
      
          
         
          
          
        <div class="col-lg-10">
          
          <div class="card mb-3">
            <div class="card-header">
              <i class="fa fa-bell-o"></i>Recent Reviews</div>
            <div class="list-group list-group-flush small">
             
			  <?php
					$sql="select * from feedback f join user u join museum m where f.user_id=u.user_id and f.museum_id=m.museum_id";
					$result=mysqli_query($conn,$sql);
					while($row=mysqli_fetch_array ($result))
					{
						?>
                <div class="media">
                  <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/45x45" alt="">
                  <div class="media-body">
                    <strong><?php echo $row['user_name']?></strong>posted a new review on
                    <strong><?php echo $row['museum_name']?></strong>.
                    <div class="text-muted smaller"><?php echo $row['feed_description']?></div>
                  </div>
                </div>
				<?php
					}
						?>
              
             
              
              
              
            </div>
            
          </div>
        </div>
      </div>
      <!-- Example DataTables Card-->
       <div class="card mb-3">
        <div class="card-header">
          </i><h2>Todays Bookings</h2></div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>booking date</th>
                  <th>museum name</th>
                  <th>user name</th>
                  <th>noofperson</th>
				  <th>totalprice</th>
				  <th>payment status</th>
				  <!--th>action</th-->
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$d = date("Y-m-d");
$sql = "select * from booking b join museum m join user u 
where b.museum_id = m.museum_id and b.user_id = u.user_id and b.booking_date = '".$d."'";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['booking_date'];?></td>
			<td> <?php echo $row['museum_name'];?></td>
			<td> <?php echo $row['user_name'];?></td>
			<td> <?php echo $row['noofperson'];?></td>
			<td> <?php echo $row['totalprice'];?></td>
			<td> <?php
			if ($row['payment_status']==0)
			{
				echo "Succesfully paid";
			}
			else
			{
				echo "Pending";
			}
			?></td>
			<!--td> <a href="delete1.php?id=<?php echo $row['user_id']?>">DELETE</a></td>
			<td> <a href="update1.php?id=<?php echo $row['user_id']?>">UPDATE</a></td-->
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    
    <!-- Scroll to Top Button-->
    
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
<?php include("footer.php");?>
