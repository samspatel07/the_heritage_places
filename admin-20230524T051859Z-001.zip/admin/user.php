<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="adminindex.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Tables</li>
      </ol>
	  <!--a href="insert1.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-fw fa-address-book"></i><h2>USER</h2></div>
		 <div>
		  <a href="Reports/user1.php"><button  type="submit" class="btn btn-success">generate report</button></a><br><br>
		  </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                 
                  <th>user name</th>
                  <th>email</th>
                  <th>address</th>
                  <th>area name</th>
				  <th>role name</th>
				  <th>action</th>
				  
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "SELECT * from user u join area a join role r where  u.area_id=a.area_id and u.role_id=r.role_id";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['user_name'];?></td>
			<td> <?php echo $row['email'];?></td>
			<td> <?php echo $row['address'];?></td>
			<td> <?php echo $row['area_name'];?></td>
			<td> <?php echo $row['role_name'];?></td>
			<td> <a href="delete1.php?id=<?php echo $row['user_id']?>">DELETE</a></td>
			<!--td> <a href="update1.php?id=<?php echo $row['user_id']?>">UPDATE</a></td-->
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
   <?php require'footer.php';?>
</html>