<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$user_id = $_GET['id'];
	

	$sql = "delete from user where user_id = $user_id";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:user.php");
	}
}	
?>