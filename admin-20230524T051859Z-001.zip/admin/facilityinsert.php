<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Form</a></li>
        <li><i class="fa fa-angle-right"></i> Form Layouts</li>
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Insert Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">facility_name</label>
                    <div class="col-md-9">
                      <input placeholder="facility_name" class="form-control" type="text" name="facility_name">
                      </div>
                  </div>
				  
				   <div class="form-group row">
                    <label class="control-label text-right col-md-3">description</label>
                    <div class="col-md-9">
                      <input placeholder="description" class="form-control" type="varchar" name="description">
                      </div>
                  </div>
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="facility.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  <?php
			  if($_SERVER["REQUEST_METHOD"]=="POST")
{

	if(isset($_POST["facility_name"]) && isset($_POST["description"]))
	
	{
		
		$facility_name = $_POST["facility_name"];
		$description = $_POST["description"];
		
	
		//if($city_name!='' && $description!='')
		{
			$sql = "insert into facility(facility_name,description)values('".$facility_name."','".$description."')";
			//echo $sql;
			//die;
			//echo "<br>".$sql;
			
			$result=mysqli_query($conn,$sql);
			
			if($result)
			{
				echo "<meta http-equiv='refresh' content='0;url=facility.php'>";
			}
			else
			{
				echo  "error";
			}
		}
	}
}
			  ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>