<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$category_id = $_GET['id'];
	

	$sql = "delete from category where category_id = $category_id";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:category.php");
	}
}	
?>