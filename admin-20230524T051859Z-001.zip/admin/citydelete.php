<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$city_id = $_GET['id'];
	

	$sql = "delete from city where city_id = $city_id";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:city.php");
	}
}	
?>