<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$museum_id = $_GET['id'];
	

	$sql = "delete from museum where museum_id = $museum_id";
	//echo $sql;
	//die;
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			  echo "<meta http-equiv='refresh' content='0;url=museum.php'>";	
	}
}	
?>