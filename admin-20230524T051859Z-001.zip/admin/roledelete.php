<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$role_id = $_GET['id'];
	

	$sql = "delete from role where role_id = $role_id";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:role.php");
	}
}	
?>