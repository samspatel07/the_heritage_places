<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>
<?php

if(isset($_GET['id']))
{
	$id = $_GET['id'];
	
	
	$sql = "select * from museum_facility where facility_id= $id";
	
	$result = mysqli_query($conn,$sql);
	
	$row = mysqli_fetch_array($result);

}

?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
		
		
		$museum_id= $_POST["museum_id"];
		$facility_id= $_POST["facility_id"];
		
		
		
	
	$sql = "update museum_facility set museum_id = '".$museum_id."', facility_id='".$facility_id."'  where facility_id=$id"; 
	//echo $sql;
	//die;
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
		  echo "<meta http-equiv='refresh' content='0;url=museum_facility.php'>";	
	}
	else
	{
		echo"error";
	}
	
}
?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="adminindex.php">Home</a></li>
       
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">update Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
					 <label class="control-label text-right col-md-3">museum name</label>
					 <div class="col-md-9">
					
						<select name='museum_id' class="form-control custom-select">
						
						
						<?php
								$sql2="select * from museum";
								$result2=mysqli_query($conn,$sql2);
								while($row2=mysqli_fetch_array($result2))
								{
									?>
									<option value="<?php echo $row2['museum_id'];?>"
									<?php if ($row2['museum_name']==$id){echo 'selected';}?>>
									<?php echo $row2['museum_name'];?>
									</option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
				<div class="form-group row">
					 <label class="control-label text-right col-md-3">facility name</label>
					 <div class="col-md-9">
					
						<select name='facility_id' class="form-control custom-select">
						
						
						
						<?php
								$sql2="select * from facility";
								$result2=mysqli_query($conn,$sql2);
								while($row2=mysqli_fetch_array($result2))
								{
									?>
									<option value="<?php echo $row2['facility_id'];?>"
									<?php if ($row2['facility_name']==$id){echo 'selected';}?>>
									<?php echo $row2['facility_name'];?>
									</option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="museum_facility.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>