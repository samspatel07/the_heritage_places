<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="adminindex.php">Home</a></li>
        
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Insert Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">city name</label>
                    <div class="col-md-9">
                      <input placeholder="city_name" class="form-control" type="text" name="city_name">
                      </div>
                  </div>
				  
				  
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="city.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  <?php
			  if($_SERVER["REQUEST_METHOD"]=="POST")
{

	if(isset($_POST["city_name"]))
	
	{
		
		$city_name = $_POST["city_name"];
		
	
		if($city_name!='')
		{
			$sql = "insert into city(city_name)values('".$city_name."')";
			//echo $sql;
			//die;
			//echo "<br>".$sql;
			
			$result=mysqli_query($conn,$sql);
			
			if($result)
			{
				echo "<meta http-equiv='refresh' content='0;url=city.php'>";
			}
			else
			{
				echo  "error";
			}
		}
	}
}
			  ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>