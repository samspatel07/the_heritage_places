<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="adminindex.php">Dashboard</a>
        </li>
        
      </ol>
	  <a href="cityinsert.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-map-marker"></i><h2>City</h2></div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>city name</th>
                  
				  <th>action</th>
				  <th>action</th>
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "SELECT * from city";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['city_name'];?></td>
			<td> <a href="citydelete.php?id=<?php echo $row['city_id']?>">DELETE</a></td>
			<td> <a href="cityupdate.php?id=<?php echo $row['city_id']?>">UPDATE</a></td>
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
   <?php require'footer.php';?>
</html>