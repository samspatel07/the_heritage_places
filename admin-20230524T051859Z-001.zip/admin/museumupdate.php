<?php

include("../config/connection1.php");

?>
<?php

if(isset($_GET['id']))
{
	$id = $_GET['id'];
	
	$sql = "select * from museum where museum_id = $id";
	
	$result = mysqli_query($conn,$sql);
	
	$row = mysqli_fetch_array($result);
	$d=$row['museum_description'];
	//echo $d;
//	die;

}

?><?php
//include("../config/connection1.php");
if($_SERVER["REQUEST_METHOD"]=="POST")
{
		
		
		$museum_name= $_POST["museum_name"];
		$museum_description = $_POST["museum_description"];
		$info = $_POST["info"];
		$starttime = $_POST["starttime"];
		$endtime = $_POST["endtime"];
		$category_id = $_POST["category_id"];
		$area_id = $_POST["area_id"];
		$museum_image = $_POST["museum_image"];
		$Price = $_POST["Price"];
		
		
	$sql = "update museum set museum_name = '".$museum_name."' ,museum_description = '".$museum_description."', info='".$info."', starttime='".$starttime."', endtime='".$endtime."',category_id='".$category_id."',area_id='".$area_id."',museum_image='".$museum_image."',Price='".$Price."' where museum_id=$id"; 
	//echo $sql;
	//die;
	
	
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
		 echo "<meta http-equiv='refresh' content='0;url=museum.php'>";
	}
	else
	{
		echo"error";
	}
	
}
?>

<?php require 'header.php';?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="adminindex.php">Home</a></li>
        
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Update Form</h5>
            </div>
                       <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">museum name</label>
                    <div class="col-md-9">
                      <input placeholder="museum_name" class="form-control" value="<?php echo $row['museum_name']?>" type="text" name="museum_name">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">description</label>
                    <div class="col-md-9">
                     <input type="text" style="height:80px" placeholder="description" class="form-control" value="<?php echo $d; ?>" name="museum_description">
                      </div>
                  </div>
				   <div class="form-group row">
                    <label class="control-label text-right col-md-3">info</label>
                    <div class="col-md-9">
                     <input type="text" style="height:80px" placeholder="info" class="form-control" value="<?php echo $row['info']?>" name="info">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">starttime</label>
                    <div class="col-md-9">
                      <input placeholder="starttime" class="form-control" value="<?php echo $row['starttime']?>" type="time" name="starttime">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">endtime</label>
                    <div class="col-md-9">
                      <input placeholder="endtime" class="form-control" value="<?php echo $row['endtime']?>" type="time" name="endtime">
                      </div>
                  </div>
				  
                 
                  
				  
				   <div class="form-group row">
					 <label class="control-label text-right col-md-3">category id</label>
					 <div class="col-md-9">
					
						<select name='category_id' class="form-control custom-select">
						
						
						
							<?php
								$sql2="select * from category";
								$result2=mysqli_query($conn,$sql2);
								while($row2=mysqli_fetch_array($result2))
								{
									?>
									<option value="<?php echo $row2['category_id'];?>"
									<?php if ($row2['category_name']==$id){echo 'selected';}?>>
									<?php echo $row2['category_name'];?>
									</option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
				<div class="form-group row">
					 <label class="control-label text-right col-md-3">area name</label>
					 <div class="col-md-9">
					
						<select name='area_id' class="form-control custom-select">
						
						
						
						
							<?php
								$sql2="select * from area";
								$result2=mysqli_query($conn,$sql2);
								while($row2=mysqli_fetch_array($result2))
								{
									?>
									<option value="<?php echo $row2['area_id'];?>"
									<?php if ($row2['area_name']==$id){echo 'selected';}?>>
									<?php echo $row2['area_name'];?>
									</option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
				
				<div class="form-group">
                        <label for="colorpicker-rgb" class="col-sm-4 control-label">File Upload field</label>
                        <div class="col-sm-8">
						
						<span class="btn btn-green fileinput-button">
                              <i class="fa fa-plus"></i>
                              <span> Select Image</span>
                              <input type="file" name="museum_image" accept="image/*" onchange="loadFile(event)">
                            </span>
						
                        </div>
                      </div>
					
					<div class="form-group">
                        <label for="colorpicker-rgb" class="col-sm-4 control-label"></label>
                        <div class="col-sm-8">  
							<img src="" id="output" height="200" width="200"  alt="">
                        </div>
                      </div>
					  
					  <script>
						function loadFile(event) {
							document.getElementById('output').src =
							URL.createObjectURL(event.target.files[0]);
						};
					  </script>
                  
                </div>
				<div class="form-group row">
                    <label class="control-label text-right col-md-3">price</label>
                    <div class="col-md-9">
                      <input placeholder="price" class="form-control" type="number" value="<?php echo $row['Price']?>" name="Price">
                      </div>
                  </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="museum.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>