<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$gallery_id = $_GET['id'];
	

	$sql = "delete from museum_gallery where gallery_id = $gallery_id";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:museum_gallary.php");
	}
}	
?>