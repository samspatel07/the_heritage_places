<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>
<?php

if(isset($_GET['id']))
{
	$id = $_GET['id'];
	
	
	$sql = "select * from category where category_id= $id";
	
	$result = mysqli_query($conn,$sql);
	
	$row = mysqli_fetch_array($result);

}

?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
		
		
		$category_name= $_POST["category_name"];
		
		
		
		
	
	$sql = "update category set category_name = '".$category_name."'  where category_id=$id"; 
	//echo $sql;
	//die;
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
		 echo "<meta http-equiv='refresh' content='0;url=category.php'>";	
	}
	else
	{
		echo"error";
	}
	
}
?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Form</a></li>
        <li><i class="fa fa-angle-right"></i> Form Layouts</li>
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">update Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">category_name</label>
                    <div class="col-md-9">
                      <input placeholder="category_name" class="form-control" value="<?php echo $row['category_name']?>" type="text" name="category_name">
                      </div>
                  </div>
				  
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="category.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  <?php