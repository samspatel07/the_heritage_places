<?php
require_once("../config/connection1.php");

if($_SERVER["REQUEST_METHOD"]=="POST")
{
   if(isset($_FILES['image'])  && isset($_POST['museum_id']))
   {
		
      $file_name = $_FILES['image']['name'];
      $file_tmp =$_FILES['image']['tmp_name'];
	 
	  $museum_id = $_POST['museum_id'];
	  
         if(move_uploaded_file($file_tmp,"../images/".$file_name)==1)
		 {
			 $query="INSERT INTO museum_gallery(image_path,museum_id) 
			 values('".$file_name."','".$museum_id."')";
			 echo $query;
			 die;
				$result=mysqli_query($conn,$query);
				
				if($result)
				{
					echo "<meta http-equiv='refresh' content='0;url=museum_gallary.php'>";
				}
				
		 }
      
	  else{
         echo "error";
      }
   }
}
?>

<?php require'header.php';?>
	<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Form</a></li>
        <li><i class="fa fa-angle-right"></i> Form Layouts</li>
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Insert Form</h5>
            </div>
			<div class="tile-body">
                    
                    <form class="form-horizontal" method="POST" role="form" enctype="multipart/form-data">
                      			  
					  
                     <div class="form-group">
                        <label for="colorpicker-rgb" class="col-sm-4 control-label">File Upload field</label>
                        <div class="col-sm-8">
						
						<span class="btn btn-green fileinput-button">
                              <i class="fa fa-plus"></i>
                              <span> Select Image</span>
                              <input type="file" name="image" accept="image/*" onchange="loadFile(event)">
                            </span>
						
                        </div>
                      </div>
					
					<div class="form-group">
                        <label for="colorpicker-rgb" class="col-sm-4 control-label"></label>
                        <div class="col-sm-8">  
							<img src="" id="output" height="200" width="200"  alt="">
                        </div>
                      </div>
					  
					  <script>
						function loadFile(event) {
							document.getElementById('output').src =
							URL.createObjectURL(event.target.files[0]);
						};
					  </script>
					  
                     
					  
					  <div class="form-group">
                        <label for="input07" class="col-sm-4 control-label">museum_id</label>
                        <div class="col-sm-8">
                          <select name="museum_id" id="select" class="form-control">
							 <?php
                                $sql="select * from museum";
								$result = mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
							 ?>
								<option value="<?php echo $row['museum_id'];?>"> <?php echo $row['museum_name'];?> 
								<?php
								}
								?>
                              </select>
                        </div>
                      </div>


					  
                      <div class="form-group form-footer">
                        <div class="col-sm-offset-4 col-sm-8">
                          <button type="submit" class="btn btn-primary">Submit</button>
                          <button type="reset" class="btn btn-default">Reset</button>
                        </div>
                      </div>

                    </form>

                  </div>
				  </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
	

       
<?php include("footer.php")?>



       