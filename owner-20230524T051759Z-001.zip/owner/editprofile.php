
<?php
session_start();
	include("header.php");
	
	

		$id=$_SESSION['email'];
		
		$sql="select * from user where user_id='".$id."'";
		
		$result = mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($result);
	
?>


<?php require 'header.php';?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="ownerindex.php">Home</a></li>
        
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">edit profile</h5>
            </div>
            <div class="card-body">
              <form  method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">user_name</label>
                    <div class="col-md-9">
                      <input  placeholder="user_name" value="<?php echo $row ['user_name']?>" class="form-control" type="text" name="user_name">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">email</label>
                    <div class="col-md-9">
                      <input  placeholder="email" value="<?php echo $row ['email']?>" class="form-control" type="text" name="email">
                      </div>
                  </div>
				   
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">address</label>
                    <div class="col-md-9">
                      <input  placeholder="address" value="<?php echo $row ['address']?>" class="form-control" type="varchar" name="address">
                      </div>
                  </div>
				 
				  
                 
                  
				  
				   <div class="form-group row">
					 <label class="control-label text-right col-md-3">area_name</label>
					 <div class="col-md-9">
					
						<select  name='area_id' class="form-control custom-select">
						
						
						<option>-select area-</option>
							<?php
								$sql="select * from area";
								$result=mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
									?>
									<option value="<?php echo $row['area_id']?>"><?php echo $row['area_name']?></option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="adminindex.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
		  <?php
//include("../config/connection1.php");
if($_SERVER["REQUEST_METHOD"]=="POST")
{
		
		//$user_id= $_GET['id'];
		$user_name= $_POST["user_name"];
		$email = $_POST["email"];
		$address = $_POST["address"];
		$area_id = $_POST["area_id"];
		
		echo "||".$user_name."||".$email."||".$address."||".$area_id."";
		
	
	$sql = "update user set user_name = '".$user_name."' ,email = '".$email."', address='".$address."', area_id='".$area_id."' where user_id='".$id."'";
	//echo $sql;
	//die;
	
	
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
		echo "<meta http-equiv='refresh' content='0;url=ownerindex.php'>";
	}
	else
	{
		echo"error";
	}
	
}
?>

        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>