<?php
include("../config/connection1.php");
if($_SERVER["REQUEST_METHOD"]=="POST")
{
		
		$user_id= $_GET['id'];
		$user_name= $_POST["user_name"];
		$email = $_POST["email"];
		$address = $_POST["address"];
		$area_id = $_POST["area_id"];
		
		echo "||".$user_name."||".$email."||".$address."||".$area_id."";
		
	
	$sql = "update user set user_name = '".$user_name."' ,email = '".$email."', address='".$address."', area_id='".$area_id."' where user_id=$user_id"; 

	//echo "<br>".$sql;
	
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
		 header("Location:user.php");	
	}
	else
	{
		echo"error";
	}
	
}
?>
