<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$museum_facility = $_GET['id'];
	

	$sql = "delete from museum_facility where museum_facility = $museum_facility";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:museum_facility.php");
	}
}	
?>