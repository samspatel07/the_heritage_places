<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Form</a></li>
        <li><i class="fa fa-angle-right"></i> Form Layouts</li>
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Insert Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">museum_name</label>
                    <div class="col-md-9">
                      <input placeholder="museum_name" class="form-control" type="text" name="museum_name">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">description</label>
                    <div class="col-md-9">
                      <input placeholder="description" class="form-control" type="text" name="museum_description">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">starttime</label>
                    <div class="col-md-9">
                      <input placeholder="starttime" class="form-control" type="time" name="starttime">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">endtime</label>
                    <div class="col-md-9">
                      <input placeholder="endtime" class="form-control" type="time" name="endtime">
                      </div>
                  </div>
				  
                 
                  
				  
				   <div class="form-group row">
					 <label class="control-label text-right col-md-3">category_id</label>
					 <div class="col-md-9">
					
						<select name='category_id' class="form-control custom-select">
						
						
						<option>-select category-</option>
							<?php
								$sql="select * from category";
								$result=mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
									?>
									<option value="<?php echo $row['category_id']?>"><?php echo $row['category_name']?></option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
				<div class="form-group row">
					 <label class="control-label text-right col-md-3">area_id</label>
					 <div class="col-md-9">
					
						<select name='area_id' class="form-control custom-select">
						
						
						
						<option>-select area id-</option>
							<?php
								$sql="select * from area";
								$result=mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
									?>
									<option value="<?php echo $row['area_id']?>"><?php echo $row['area_name']?></option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
				
				<div class="form-group">
                        <label for="colorpicker-rgb" class="col-sm-4 control-label">File Upload field</label>
                        <div class="col-sm-8">
						
						<span class="btn btn-green fileinput-button">
                              <i class="fa fa-plus"></i>
                              <span> Select Image</span>
                              <input type="file" name="museum_image" accept="image/*" onchange="loadFile(event)">
                            </span>
						
                        </div>
                      </div>
					
					<div class="form-group">
                        <label for="colorpicker-rgb" class="col-sm-4 control-label"></label>
                        <div class="col-sm-8">  
							<img src="" id="output" height="200" width="200"  alt="">
                        </div>
                      </div>
					  
					  <script>
						function loadFile(event) {
							document.getElementById('output').src =
							URL.createObjectURL(event.target.files[0]);
						};
					  </script>
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="museum.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  <?php
			  if($_SERVER["REQUEST_METHOD"]=="POST")
{

	if(isset($_POST["museum_name"]) && isset($_POST["museum_description"]) && isset($_POST["starttime"]) && isset($_POST["endtime"]) 
		&& isset($_POST["category_id"]) && isset($_POST["area_id"]) && isset($_POST["museum_image"]))
	
	{
		
		$museum_name = $_POST["museum_name"];
		$museum_description = $_POST["museum_description"];
		$starttime = $_POST["starttime"];
		$endtime = $_POST["endtime"];
		$category_id = $_POST["category_id"];
		$area_id = $_POST["area_id"];
		$museum_image = $_POST["museum_image"];
	
		if($museum_name!='' && $museum_description!='' && $starttime!='' && $endtime!='' && $category_id!='' && $area_id!='' && $museum_image!='')
		{
			$sql = "insert into museum(museum_name,museum_description,starttime,endtime,category_id,area_id,museum_image)values('".$museum_name."','".$description."','".$starttime."','".$endtime."','".$category_id."','".$area_id."','".$museum_image."')";
			//echo $sql;
			//die;
			//echo "<br>".$sql;
			
			$result=mysqli_query($conn,$sql);
			
			if($result)
			{
				echo "<meta http-equiv='refresh' content='0;url=museum.php'>";
			}
			else
			{
				echo  "error";
			}
		}
	}
}
			  ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>