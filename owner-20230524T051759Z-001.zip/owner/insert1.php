<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Form</a></li>
        <li><i class="fa fa-angle-right"></i> Form Layouts</li>
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Insert Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">user_name</label>
                    <div class="col-md-9">
                      <input placeholder="user_name" class="form-control" type="text" name="user_name">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">email</label>
                    <div class="col-md-9">
                      <input placeholder="email" class="form-control" type="text" name="email">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">address</label>
                    <div class="col-md-9">
                      <input placeholder="address" class="form-control" type="varchar" name="address">
                      </div>
                  </div>
				  <div class="form-group row">
                    <label class="control-label text-right col-md-3">Password</label>
                    <div class="col-md-9">
                      <input placeholder="Password" class="form-control" type="password" name="password">
                      </div>
                  </div>
				  
                 
                  
				  
				   <div class="form-group row">
					 <label class="control-label text-right col-md-3">area_id</label>
					 <div class="col-md-9">
					
						<select name='area_id' class="form-control custom-select">
						
						
						<option>-select area-</option>
							<?php
								$sql="select * from area";
								$result=mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
									?>
									<option value="<?php echo $row['area_id']?>"><?php echo $row['area_name']?></option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
				<div class="form-group row">
					 <label class="control-label text-right col-md-3">role_id</label>
					 <div class="col-md-9">
					
						<select name='role_id' class="form-control custom-select">
						
						
						
						<option>-select role id-</option>
							<?php
								$sql="select * from role";
								$result=mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
									?>
									<option value="<?php echo $row['role_id']?>"><?php echo $row['role_name']?></option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="user.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  <?php
			  if($_SERVER["REQUEST_METHOD"]=="POST")
{

	if(isset($_POST["user_name"]) && isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["address"]) 
		&& isset($_POST["area_id"]) && isset($_POST["role_id"]))
	
	{
		
		$user_name = $_POST["user_name"];
		$email = $_POST["email"];
		$password = $_POST["password"];
		$address = $_POST["address"];
		$area_id = $_POST["area_id"];
		$role_id = $_POST["role_id"];
	
		if($user_name!='' && $email!='' && $password!='' && $address!='' && $area_id!='' && $role_id!='')
		{
			$sql = "insert into user(user_name,email,password,address,area_id,role_id)values('".$user_name."','".$email."','".$password."','".$address."','".$area_id."','".$role_id."')";
			//echo $sql;
			//die;
			//echo "<br>".$sql;
			
			$result=mysqli_query($conn,$sql);
			
			if($result)
			{
				echo "<meta http-equiv='refresh' content='0;url=user.php'>";
			}
			else
			{
				echo  "error";
			}
		}
	}
}
			  ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>