<?php

require_once("../config/connection1.php");



?>
<?php require 'header.php';?>

  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    <div class="content-header sty-two">
      <h1 class="text-white">Form Layouts</h1>
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Form</a></li>
        <li><i class="fa fa-angle-right"></i> Form Layouts</li>
      </ol>
    </div>
    
    <!-- Main content -->
    <div class="content">     
      <div class="row m-t-3">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header bg-blue">
              <h5 class="m-b-0">Insert Form</h5>
            </div>
            <div class="card-body">
              <form action="" method="POST" class="form-horizontal form-bordered">
                <div class="form-body">
                  <div class="form-group row">
                    <label class="control-label text-right col-md-3">area_name</label>
                    <div class="col-md-9">
                      <input placeholder="area_name" class="form-control" type="text" name="area_name">
                      </div>
                  </div>
				  
				  <div class="form-group row">
					 <label class="control-label text-right col-md-3">city_id</label>
					 <div class="col-md-9">
					
						<select name="city_id" class="form-control custom-select">
						
						
						<option>-select area-</option>
							<?php
								$sql="select * from city";
								$result=mysqli_query($conn,$sql);
								while($row=mysqli_fetch_array($result))
								{
									?>
									<option value="<?php echo $row['city_id']?>"><?php echo $row['city_name']?></option>
									<?php
								}
									?>
						</select>
				</div>
				</div>
				  
                  
                </div>
                <div class="form-actions">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="offset-sm-3 col-md-9">
                          <button type="submit" name="submit" class="btn btn-success"> Submit</button>
                          <button type="button" class="btn btn-inverse"><a href="area.php">Cancel</a></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
			  <?php
			  if($_SERVER["REQUEST_METHOD"]=="POST")
{

	if(isset($_POST["area_name"]) && isset($_POST["city_id"]))
	
	{
		
		$area_name = $_POST["area_name"];
		$city_id=$_POST["city_id"];
		
	
		if($area_name!='')
		{
			$sql = "insert into area(area_name,city_id)values('".$area_name."','".$city_id."')";
			//echo $sql;
			//die;
			//echo "<br>".$sql;
			
			$result=mysqli_query($conn,$sql);
			
			if($result)
			{
				echo "<meta http-equiv='refresh' content='0;url=area.php'>";
			}
			else
			{
				echo  "error";
			}
		}
	}
}
			  ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content --> 
  </div>
  <?php require 'footer.php';?>