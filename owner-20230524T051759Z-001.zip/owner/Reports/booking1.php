<?php
include('config.php');
$database = new Database();
$result = $database->runQuery("select u.user_name,a.museum_name,b.booking_date,b.totalprice,b.noofperson from user u join museum a join booking b where b.user_id=u.user_id and b.museum_id=a.museum_id");
$header = $database->runQuery("SELECT UCASE(`COLUMN_NAME`) 
FROM `INFORMATION_SCHEMA`.`COLUMNS` 
WHERE `TABLE_SCHEMA`='museum_locator' 
AND `TABLE_NAME`='booking'
and `COLUMN_NAME` in ('user_name','museum_name','booking_date','total_price','noofperson')");
require('fpdf/fpdf.php');
$pdf = new FPDF();
$pdf->AddPage("L","A4");
$pdf->SetFont('Arial','B',10);

// Set header
 $pdf->Image('new.png',7,1,50);
    // Move to the right
    $pdf->Cell(80);			
    // Title
    $pdf->Cell(60,10,'booking List',1,0,'C');
    // Line break
    $pdf->Ln(20);

/*
foreach($header as $heading) {
	foreach($heading as $column_heading)
		$pdf->Cell(70,12,$column_heading,1);
}
*/
		
		$pdf->Cell(60,20,"User Name",1);
		//$pdf->Cell(20,20,"Last Name",1);
		$pdf->Cell(60,20,"museum Name",1);
		$pdf->Cell(60,20,"date",1);
		$pdf->Cell(60,20,"Price",1);
		$pdf->Cell(60,20,"person",1);
		//$pdf->Cell(60,20,"registered date",1);
		//$pdf->Cell(60,20,"Contact No",1);
foreach($result as $row) {
	$pdf->Ln();
	foreach($row as $column)
		$pdf->Cell(60,10,$column,1);
}
$pdf->Output();

// Set footer
   $pdf->SetY(-15);
    // Arial italic 8
    $pdf->SetFont('Arial','I',8);
    // Page number
    $pdf->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
?>