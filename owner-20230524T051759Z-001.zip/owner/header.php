<!DOCTYPE html>
<?php

require_once("../config/connection1.php");

session_start();

?>
<?php
if(isset($_SESSION['user_id']))
{
$id=$_SESSION['user_id'];
$sql="select * from user where user_id=$id";
$result=mysqli_query($conn,$sql);
$row1=mysqli_fetch_array($result);

}
?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="The Heritage Places - Locate Heritage Places in Gujarat and Rajasthan">
  <meta name="author" content="Parth, Savan, Arish, Maulik">
  <title>The Heritage Places - Ownerr</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
     <div class="col-md-3">
                            <a class="logo" href="ownerindex.php">
                                <img src="img/logo.png" alt="Image Alternative text" style="height:55px;padding;0px" title="Image Title" />
                            </a>
                        </div>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User">
          <a class="nav-link" href="user.php">
            <i class="fa fa-fw fa-address-book"></i>
            <span class="nav-link-text">User</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="area">
          <a class="nav-link" href="area.php">
            <i class="fa fa-home"></i>
            <span class="nav-link-text">Area</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="city">
          <a class="nav-link" href="city.php">
            <i class="fa fa-map-marker"></i>
            <span class="nav-link-text">city</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="museum">
          <a class="nav-link" href="museum.php">
            <i class="fa fa-university"></i>
            <span class="nav-link-text">museum</span>
          </a>
        </li>

		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="museum_gallary">
          <a class="nav-link" href="museum_gallary.php">
            <i class="fa fa-image"></i>
            <span class="nav-link-text">museum_gallary</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="museum_facility">
          <a class="nav-link" href="museum_facility.php">
            <i class="fa fa-rss-square"></i>
            <span class="nav-link-text">museum_facility</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="facility">
          <a class="nav-link" href="facility.php">
            <i class="fa fa-wifi"></i>
            <span class="nav-link-text">facility</span>
          </a>
        </li>

		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="feedback">
          <a class="nav-link" href="feedback.php">
            <i class="fa fa-id-card-o"></i>
            <span class="nav-link-text">feedback</span>
          </a>
        </li>

		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="role">
          <a class="nav-link" href="role.php">
            <i class="fa fa-users"></i>
            <span class="nav-link-text">role</span>
          </a>
        </li>

		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="category">
          <a class="nav-link" href="category.php">
            <i class="fa fa-ellipsis-h"></i>
            <span class="nav-link-text">category</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="booking">
          <a class="nav-link" href="booking.php">
            <i class="fa fa-tablet"></i>
            <span class="nav-link-text">booking</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="contactus">
          <a class="nav-link" href="contactus.php">
            <i class="fa fa-tablet"></i>
            <span class="nav-link-text">contact us</span>
          </a>
        </li>





      </ul>
      <ul class="navbar-nav ml-auto">
         <li class="nav-item">
		 <?php
								if(isset($_SESSION['user_id']))
								{

								?>
          <a href="editprofile.php">

            Hi&nbsp;&nbsp;<?php echo $row1['user_name']; ?></a>
        </li>
		<?php
								}
?>

		<?php
								if(!isset($_SESSION['user_id']))
								{
								?>
		<li class="nav-item">
          <a href="../client/login.php">
            Login</a>
        </li>
		<?php
								}
?>

        <?php
								if(isset($_SESSION['user_id']))
								{
								?>

        <li class="nav-item">
          <a href="ownerlogout.php">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
		<?php
								}
								?>
      </ul>
    </div>
  </nav>
