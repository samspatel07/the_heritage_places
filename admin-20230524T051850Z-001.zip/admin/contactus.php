<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="adminindex.php">Dashboard</a>
        </li>
        
      </ol>
	  <!--a href="cityinsert.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-map-marker"></i><h2>contact us</h2></div>
		  <div >
		  <a href="Reports/newinquiry.php"><button  type="submit" class="btn btn-success">generate report</button></a><br><br>
		  </div>
		  
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>contact name</th>
				  <th>contact email</th>
				  <th>museum name</th>
				  <th>message</th>
				  
                  
				  
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "SELECT * from contact_us c join museum m where c.museum_id=m.museum_id";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['contact_name'];?></td>
			<td> <?php echo $row['contact_email'];?></td>
			<td> <?php echo $row['museum_name'];?></td>
			<td> <?php echo $row['message'];?></td>
			
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
      
      </div>
    </div>
   <?php require'footer.php';?>
</html>