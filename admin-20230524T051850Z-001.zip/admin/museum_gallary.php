<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="adminindex.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Tables</li>
      </ol>
	  <a href="museum_gallaryinsert.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-image"></i> <h2>Museum gallary</h2> </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>image path</th>
				  <th>museum name</th>
                  
				  <th>action</th>
				  
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "SELECT * from museum_gallery n join museum m where n.museum_id=m.museum_id";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			<td> <?php echo $row['image_path'];?></td>
			<td> <?php echo $row['museum_name'];?></td>
			<td> <a href="museum_gallarydelete.php?id=<?php echo $row['gallery_id']?>">DELETE</a></td>
			
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
   <?php require'footer.php';?>
</html>