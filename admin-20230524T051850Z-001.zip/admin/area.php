<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="adminindex.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Tables</li>
      </ol>
	  <a href="areainsert.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-home"></i> <h2>Area Table</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>area name</th>
                  <th>city name</th>
				  <th>action</th>
				  <th>action</th>
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql ="SELECT * from area a join city c where  a.area_id=a.area_id and c.city_id=a.city_id";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['area_name'];?></td>
			<td> <?php echo $row['city_name'];?></td>
			<td> <a href="areadelete.php?id=<?php echo $row['area_id']?>">DELETE</a></td>
			<td> <a href="areaupdate.php?id=<?php echo $row['area_id']?>&area=<?php echo $row['city_name'];?>">UPDATE</a></td>
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
   <?php require'footer.php';?>
</html>