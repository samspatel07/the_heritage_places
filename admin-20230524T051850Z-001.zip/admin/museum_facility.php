<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Tables</li>
      </ol>
	  <a href="museum_facilityinsert.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-rss-square"></i><h2>Museum facility</h2></div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
				  <th>museum name</th>
				  <th>facility name</th>
                  <th>action</th>
				  <th>action</th>
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "SELECT * from museum_facility m join museum n join facility f where m.museum_id = n.museum_id and m.facility_id=f.facility_id";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['museum_name'];?></td>
			<td> <?php echo $row['facility_name'];?></td>
			<td> <a href="museum_facilitydelete.php?id=<?php echo $row['museum_facility']?>">DELETE</a></td>
			<td> <a href="museum_facilityupdate.php?id=<?php echo $row['museum_facility']?>">UPDATE</a></td>
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
   <?php require'footer.php';?>
</html>