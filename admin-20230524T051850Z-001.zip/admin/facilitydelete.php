<?php
require_once("../config/connection1.php");

if(isset($_GET['id']))
{

	$facility_id = $_GET['id'];
	

	$sql = "delete from facility where facility_id = $facility_id";
	
	$result = mysqli_query($conn,$sql);
	
	if($result)
	{
			header("Location:facility.php");
	}
}	
?>