<html>
<?php require'header.php';?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Tables</li>
      </ol>
	  <a href="facilityinsert.php"><button type="submit" class="btn btn-success">Insert data</button></a><br><br>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-wifi"></i><h2>Facility</h2></div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  
                  <th>facility name</th>
                  <th>description</th>
				  <th>action</th>
				  <th>action</th>
                </tr>
              </thead>
              
              <tbody>
               
                <?php
require_once("../config/connection1.php");
$sql = "SELECT * from facility ";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
	
{
?>
		<tr>
			
			<td> <?php echo $row['facility_name'];?></td>
			<td> <?php echo $row['description'];?></td>
			<td> <a href="facilitydelete.php?id=<?php echo $row['facility_id']?>">DELETE</a></td>
			<td> <a href="facilityupdate.php?id=<?php echo $row['facility_id']?>">UPDATE</a></td>
			</tr>
<?php
}
?>
              </tbody>
            </table>
          </div>
        </div>
       <!-- <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div-->
      </div>
    </div>
   <?php require'footer.php';?>
</html>